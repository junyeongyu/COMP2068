"use strict";
var Hero = (function () {
    function Hero() {
    }
    return Hero;
}());
exports.Hero = Hero;
