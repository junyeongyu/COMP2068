

# Assignment1

This Express site includes the pages from your Personal Portfolio 5 pages.<br />
 * A Home page
 * An About Me page
 * A Projects page
 * A Services page
 * A Contact Me page

## Technologies

* Back End
 - NodeJS
 - Express
 - MongoDB

* Front End
 - Angular 2

## Usage

$ npm start